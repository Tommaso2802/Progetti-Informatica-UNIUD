#!/usr/bin/env python3
"""Genera popolamento.sql, una piccola base di dati di esempio.

Il seme del generatore casuale e' fisso: rieseguendo lo script si ottiene
sempre lo stesso file. Tutti gli inserimenti sono racchiusi in un'unica
transazione: se un inserimento fallisce, nessuna tupla viene registrata.
"""

import random
from pathlib import Path

random.seed(7)

OUT = Path(__file__).resolve().parent / "popolamento.sql"

N_AZIENDE = 10
N_STAZIONI = 30

COMUNI = [("Udine", "UD"), ("Codroipo", "UD"), ("Palmanova", "UD"),
          ("Cervignano del Friuli", "UD"), ("Latisana", "UD"),
          ("Tolmezzo", "UD"), ("Pordenone", "PN"), ("Sacile", "PN"),
          ("Spilimbergo", "PN"), ("Maniago", "PN"), ("Gorizia", "GO"),
          ("Monfalcone", "GO"), ("Cormons", "GO"), ("Trieste", "TS"),
          ("Muggia", "TS"), ("Duino Aurisina", "TS")]
CODICE_PROVINCIA = {"UD": "030", "PN": "093", "GO": "031", "TS": "032"}

CARBURANTI = [("Benzina", False), ("Gasolio", False),
              ("Gasolio Premium", False), ("HVO", False),
              ("GPL", True), ("Metano", True)]

NOMI = ["Marco", "Luca", "Andrea", "Francesca", "Giulia", "Sara", "Paolo",
        "Anna", "Elena", "Davide", "Chiara", "Stefano", "Laura", "Matteo",
        "Fabio", "Silvia", "Nicola", "Elisa", "Giorgio", "Marta"]
COGNOMI = ["Rossi", "Furlan", "Bortolussi", "Zanin", "Cossutta", "Marini",
           "Toffoli", "Visintin", "Fabbro", "Moro", "Comelli", "Degano",
           "Michelutti", "Zuliani", "Pahor", "Snidero", "Tomasin", "Venier"]
GIORNI = ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"]
MESI = "ABCDEHLMPRST"   # lettere del mese nel codice fiscale


def q(s):
    return "'" + s.replace("'", "''") + "'"


def insert(tabella, righe):
    valori = ",\n".join("    (" + ", ".join(r) + ")" for r in righe)
    return f"insert into {tabella} values\n{valori};\n"


aziende = [f"A{i:03d}" for i in range(1, N_AZIENDE + 1)]
stazioni = [f"S{i:03d}" for i in range(1, N_STAZIONI + 1)]

# ogni azienda possiede almeno una stazione; le altre stazioni vanno
# soprattutto alle prime tre aziende
proprietaria = dict(zip(stazioni, aziende))
for s in stazioni[N_AZIENDE:]:
    proprietaria[s] = random.choices(aziende, weights=[5, 4, 3] + [1] * 7)[0]
stazioni_di = {a: [s for s in stazioni if proprietaria[s] == a]
               for a in aziende}
# ogni comune dell'elenco ospita almeno una stazione, quindi tutti i
# comuni registrati sono coinvolti (V5)
nomi_comuni = random.sample([n for n, _ in COMUNI], len(COMUNI))
comune_di = dict(zip(stazioni, nomi_comuni))
for s in stazioni[len(COMUNI):]:
    comune_di[s] = random.choice(COMUNI)[0]
sede = {a: comune_di[stazioni_di[a][0]] for a in aziende}

# carburanti offerti: benzina e gasolio ovunque, gas in poche stazioni
offerti = {}
for s in stazioni:
    offerti[s] = ["Benzina", "Gasolio"]
    offerti[s] += [c for c in ("Gasolio Premium", "HVO") if random.random() < 0.3]
    if random.random() < 0.25:
        offerti[s] += random.choice([["GPL"], ["Metano"], ["GPL", "Metano"]])

# pompe: almeno una per carburante offerto, piu' qualche pompa in aggiunta
pompe = []
for s in stazioni:
    carburanti = offerti[s] + random.choices(offerti[s], k=random.randint(0, 2))
    for n, c in enumerate(sorted(carburanti), start=1):
        stato = random.choices(["ATTIVA", "MANUTENZIONE"], weights=[9, 1])[0]
        pompe.append((s, n, c, stato))

# dipendenti e piano di lavoro: i turni sono solo su stazioni
# dell'azienda del dipendente (V3), che risiede spesso vicino al lavoro
dipendenti, piani, codici = [], [], set()
for a in aziende:
    for _ in range(len(stazioni_di[a]) + random.randint(0, 2)):
        nome, cognome = random.choice(NOMI), random.choice(COGNOMI)
        cf = ""
        while cf == "" or cf in codici:
            cf = (cognome[:3].upper() + nome[:3].upper()
                  + f"{random.randint(60, 99)}{random.choice(MESI)}"
                  + f"{random.randint(1, 28):02d}L483"
                  + random.choice("ABCDEFGHLMNPRSTVZ"))
        codici.add(cf)
        if random.random() < 0.6:
            residenza = comune_di[random.choice(stazioni_di[a])]
        else:
            residenza = random.choice(COMUNI)[0]
        telefono = f"+3933{random.randint(10000000, 99999999)}"
        stipendio = f"{random.uniform(1400, 2400):.2f}"
        dipendenti.append((cf, a, nome, cognome, residenza, telefono, stipendio))
        for g in sorted(random.sample(GIORNI, 5), key=GIORNI.index):
            turno = random.choice([("06:00", "14:00"), ("14:00", "22:00")])
            piani.append((cf, g, random.choice(stazioni_di[a])) + turno)

# codice ISTAT fittizio: codice della provincia seguito da un progressivo
istat = {n: CODICE_PROVINCIA[p] + f"{i:03d}"
         for i, (n, p) in enumerate(COMUNI, start=1)}

sql = ["-- popolamento della base di dati, generato da genera_popolamento.py",
       "start transaction;",
       insert("Comune", [(q(n), q(p), q(istat[n])) for n, p in COMUNI]),
       insert("Carburante", [(q(n), "TRUE" if g else "FALSE")
                             for n, g in CARBURANTI]),
       insert("Azienda", [(q(a), q(random.choice(NOMI)),
                           q(random.choice(COGNOMI)),
                           q(f"+39043{random.randint(1000000, 9999999)}"),
                           q(sede[a])) for a in aziende]),
       insert("Stazione", [(q(s), q(proprietaria[s]), q(comune_di[s]),
                            f"{random.uniform(45.60, 46.50):.6f}",
                            f"{random.uniform(12.40, 13.80):.6f}")
                           for s in stazioni])]
offerte = []
for s in stazioni:
    for c in offerti[s]:
        capacita = random.choice([10000, 15000, 20000])
        quantita = capacita * random.uniform(0.1, 0.9)
        offerte.append((q(s), q(c), f"{capacita}.00", f"{quantita:.2f}"))
sql += [insert("Offre", offerte),
        insert("Pompa", [(q(s), str(n), q(c), q(st)) for s, n, c, st in pompe]),
        insert("Dipendente", [(q(cf), q(a), q(n), q(c), q(r), q(t), st)
                              for cf, a, n, c, r, t, st in dipendenti]),
        insert("PianoDiLavoro", [(q(cf), q(g), q(s), q(i), q(f))
                                 for cf, g, s, i, f in piani]),
        "commit;"]
OUT.write_text("\n".join(sql) + "\n", encoding="utf-8")

print(f"comuni {len(COMUNI)}, aziende {len(aziende)}, "
      f"stazioni {len(stazioni)}, carburanti {len(CARBURANTI)}, "
      f"offerte {len(offerte)}, pompe {len(pompe)}, "
      f"dipendenti {len(dipendenti)}, piani {len(piani)}")
