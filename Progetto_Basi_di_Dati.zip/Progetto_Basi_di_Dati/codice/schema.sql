create domain dom_CodiceAzienda as varchar(20);
create domain dom_CodiceStazione as varchar(20);
create domain dom_CodiceFiscale as char(16);
create domain dom_NomeComune as varchar(60);
create domain dom_NomeCarburante as varchar(30);
create domain dom_Telefono as varchar(20); --include il prefisso +xx
create domain dom_Giorno as char(3)
    CONSTRAINT valoreGiorno
    CHECK(value in ('LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'));
create domain dom_StatoPompa as varchar(15)
    DEFAULT 'ATTIVA'
    CONSTRAINT valoreStatoPompa
    CHECK(value in ('ATTIVA', 'MANUTENZIONE', 'FUORI_SERVIZIO'));

create table Comune(
    NomeComune dom_NomeComune,
    Provincia char(2) not null,
    CodiceISTAT char(6) not null unique,

    PRIMARY KEY(NomeComune)
);

create table Azienda(
    CodiceAzienda dom_CodiceAzienda,
    NomeResponsabile varchar(60) not null,
    CognomeResponsabile varchar(60) not null,
    TelefonoResponsabile dom_Telefono not null,
    ComuneSede dom_NomeComune not null,

    PRIMARY KEY(CodiceAzienda),
    CONSTRAINT FkComuneSede FOREIGN KEY(ComuneSede)
        references Comune(NomeComune)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);

create table Stazione(
    CodiceStazione dom_CodiceStazione,
    CodiceAzienda dom_CodiceAzienda not null,
    Comune dom_NomeComune not null,
    Latitudine decimal(9,6) not null,
    Longitudine decimal(9,6) not null,

    PRIMARY KEY(CodiceStazione),
    CONSTRAINT FkProprietaria FOREIGN KEY(CodiceAzienda)
        references Azienda(CodiceAzienda)
        ON UPDATE CASCADE
        ON DELETE NO ACTION,
    CONSTRAINT FkComuneStazione FOREIGN KEY(Comune)
        references Comune(NomeComune)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);

create table Carburante(
    Nome dom_NomeCarburante,
    EGas boolean DEFAULT FALSE not null,

    PRIMARY KEY(Nome)
);

create table Offre(
    CodiceStazione dom_CodiceStazione,
    NomeCarburante dom_NomeCarburante,
    CapacitaMassima decimal(10,2) not null,
    QuantitaDisponibile decimal(10,2) not null,

    PRIMARY KEY(CodiceStazione, NomeCarburante),
    CHECK (CapacitaMassima > 0),
    CHECK (QuantitaDisponibile >= 0 and QuantitaDisponibile <= CapacitaMassima),
    CONSTRAINT FkStazioneOffre FOREIGN KEY(CodiceStazione)
        references Stazione(CodiceStazione)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT FkCarburanteOffre FOREIGN KEY(NomeCarburante)
        references Carburante(Nome)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);

create table Pompa(
    CodiceStazione dom_CodiceStazione,
    NumeroPompa integer,
    NomeCarburante dom_NomeCarburante not null,
    StatoOperativo dom_StatoPompa not null,

    PRIMARY KEY(CodiceStazione, NumeroPompa),
    CHECK (NumeroPompa > 0),
    --la pompa puo' erogare solo un carburante offerto dalla sua stazione
    CONSTRAINT FkErogazione FOREIGN KEY(CodiceStazione, NomeCarburante)
        references Offre(CodiceStazione, NomeCarburante)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

create table Dipendente(
    CodiceFiscale dom_CodiceFiscale,
    CodiceAzienda dom_CodiceAzienda not null,
    Nome varchar(60) not null,
    Cognome varchar(60) not null,
    ComuneResidenza dom_NomeComune not null,
    Telefono dom_Telefono not null,
    Stipendio decimal(8,2) not null,

    PRIMARY KEY(CodiceFiscale),
    CHECK (Stipendio > 0),
    CONSTRAINT FkDatoreLavoro FOREIGN KEY(CodiceAzienda)
        references Azienda(CodiceAzienda)
        ON UPDATE CASCADE
        ON DELETE NO ACTION,
    CONSTRAINT FkResidenza FOREIGN KEY(ComuneResidenza)
        references Comune(NomeComune)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);

create table PianoDiLavoro(
    CodiceFiscale dom_CodiceFiscale,
    Giorno dom_Giorno,
    CodiceStazione dom_CodiceStazione not null,
    OraInizio time not null,
    OraFine time not null,

    PRIMARY KEY(CodiceFiscale, Giorno),
    CHECK (OraFine > OraInizio),
    CONSTRAINT FkTurnista FOREIGN KEY(CodiceFiscale)
        references Dipendente(CodiceFiscale)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT FkStazioneTurno FOREIGN KEY(CodiceStazione)
        references Stazione(CodiceStazione)
        ON UPDATE CASCADE
        ON DELETE NO ACTION
);

create view StazioneGas as
    SELECT DISTINCT O.CodiceStazione
    FROM Offre AS O, Carburante AS C
    WHERE O.NomeCarburante = C.Nome AND C.EGas = TRUE;
