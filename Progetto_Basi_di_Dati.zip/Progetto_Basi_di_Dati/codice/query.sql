-- 1 Trovare le stazioni di rifornimento con il massimo numero di pompe che
--   erogano gas

create view PompeGas as
    SELECT P.CodiceStazione, COUNT(*) AS NumeroPompeGas
    FROM Pompa AS P, Carburante AS C
    WHERE P.NomeCarburante = C.Nome AND C.EGas = TRUE
    GROUP BY P.CodiceStazione;

SELECT G.CodiceStazione, G.NumeroPompeGas
FROM PompeGas AS G
WHERE NOT EXISTS (SELECT *
                  FROM PompeGas AS G2
                  WHERE G2.NumeroPompeGas > G.NumeroPompeGas);

-- 2 Per ogni comune, restituire il numero di stazioni di rifornimento di una
--   data azienda

SELECT C.NomeComune, COUNT(S.CodiceStazione) AS NumeroStazioni
FROM Comune AS C LEFT JOIN Stazione AS S
     ON S.Comune = C.NomeComune AND S.CodiceAzienda = 'A001'
GROUP BY C.NomeComune
ORDER BY C.NomeComune;

-- 3 Tutti i dipendenti che lavorano presso una stazione che puo' erogare un
--   carburante con quantita' disponibile almeno X e al massimo Y

SELECT DISTINCT D.CodiceFiscale, D.Nome, D.Cognome
FROM Dipendente AS D, PianoDiLavoro AS L, Pompa AS P, Offre AS O
WHERE D.CodiceFiscale = L.CodiceFiscale
  AND L.CodiceStazione = P.CodiceStazione
  AND P.CodiceStazione = O.CodiceStazione
  AND P.NomeCarburante = O.NomeCarburante
  AND O.QuantitaDisponibile BETWEEN 1000 AND 3000;

-- 4 Tutti i dipendenti la cui residenza e' uguale a quella di almeno altri
--   due dipendenti che lavorano nella stessa azienda

SELECT D.CodiceFiscale, D.Nome, D.Cognome, D.ComuneResidenza,
       D.CodiceAzienda
FROM Dipendente AS D
WHERE (SELECT COUNT(*)
       FROM Dipendente AS D2
       WHERE D2.CodiceAzienda = D.CodiceAzienda
         AND D2.ComuneResidenza = D.ComuneResidenza
         AND D2.CodiceFiscale <> D.CodiceFiscale) >= 2
ORDER BY D.CodiceAzienda, D.ComuneResidenza;
