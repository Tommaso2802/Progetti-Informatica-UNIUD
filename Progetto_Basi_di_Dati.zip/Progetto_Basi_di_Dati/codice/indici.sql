CREATE INDEX indice_comune_in_stazione ON Stazione (Comune);

CREATE INDEX indice_stazione_giorno_in_piano ON PianoDiLavoro (CodiceStazione,
    Giorno);
