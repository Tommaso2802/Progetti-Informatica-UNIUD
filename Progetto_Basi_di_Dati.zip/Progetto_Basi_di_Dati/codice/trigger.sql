--ogni azienda possiede almeno una stazione (AZIENDA (1,N) in POSSIEDE)
create or replace function verifica_stazioni_azienda()
returns trigger language plpgsql as
$$
declare
   n_stazioni integer;
begin
   --se l'azienda non esiste piu' (modifica del codice propagata in
   --cascata) non c'e' nulla da verificare
   perform * from Azienda where CodiceAzienda = old.CodiceAzienda;
   if found then
      select count(*) into n_stazioni
      from Stazione
      where Stazione.CodiceAzienda = old.CodiceAzienda;

      if n_stazioni <= 1 then
         raise exception 'L''azienda % deve possedere almeno una stazione',
            old.CodiceAzienda;
      end if;
   end if;

   if (TG_OP = 'DELETE') then
      return old;
   elsif (TG_OP = 'UPDATE') then
      return new;
   end if;
end;
$$;

create trigger stazioni_azienda_del
before delete on Stazione
for each row execute function verifica_stazioni_azienda();

create trigger stazioni_azienda_upd
before update on Stazione
for each row
when (new.CodiceAzienda <> old.CodiceAzienda)
execute function verifica_stazioni_azienda();

--ogni azienda impiega almeno un dipendente (AZIENDA (1,N) in LAVORA)
create or replace function verifica_dipendenti_azienda()
returns trigger language plpgsql as
$$
declare
   n_dipendenti integer;
begin
   --se l'azienda non esiste piu' (modifica del codice propagata in
   --cascata) non c'e' nulla da verificare
   perform * from Azienda where CodiceAzienda = old.CodiceAzienda;
   if found then
      select count(*) into n_dipendenti
      from Dipendente
      where Dipendente.CodiceAzienda = old.CodiceAzienda;

      if n_dipendenti <= 1 then
         raise exception 'L''azienda % deve avere almeno un dipendente',
            old.CodiceAzienda;
      end if;
   end if;

   if (TG_OP = 'DELETE') then
      return old;
   elsif (TG_OP = 'UPDATE') then
      return new;
   end if;
end;
$$;

create trigger dipendenti_azienda_del
before delete on Dipendente
for each row execute function verifica_dipendenti_azienda();

create trigger dipendenti_azienda_upd
before update on Dipendente
for each row
when (new.CodiceAzienda <> old.CodiceAzienda)
execute function verifica_dipendenti_azienda();

--ogni stazione offre almeno un carburante (STAZIONE (1,N) in OFFRE)
create or replace function verifica_carburanti_stazione()
returns trigger language plpgsql as
$$
declare
   n_carburanti integer;
begin
   --se la stazione non esiste piu' (cancellazione o modifica del
   --codice propagate in cascata) non c'e' nulla da verificare
   perform * from Stazione where CodiceStazione = old.CodiceStazione;
   if found then
      select count(*) into n_carburanti
      from Offre
      where Offre.CodiceStazione = old.CodiceStazione;

      if n_carburanti <= 1 then
         raise exception 'La stazione % deve offrire almeno un carburante',
            old.CodiceStazione;
      end if;
   end if;

   if (TG_OP = 'DELETE') then
      return old;
   elsif (TG_OP = 'UPDATE') then
      return new;
   end if;
end;
$$;

create trigger carburanti_stazione_del
before delete on Offre
for each row execute function verifica_carburanti_stazione();

create trigger carburanti_stazione_upd
before update on Offre
for each row
when (new.CodiceStazione <> old.CodiceStazione)
execute function verifica_carburanti_stazione();

--ogni stazione dispone di almeno una pompa (STAZIONE (1,N) in COMPRENDE)
create or replace function verifica_pompe_stazione()
returns trigger language plpgsql as
$$
declare
   n_pompe integer;
begin
   --se la stazione non esiste piu' (cancellazione o modifica del
   --codice propagate in cascata) non c'e' nulla da verificare
   perform * from Stazione where CodiceStazione = old.CodiceStazione;
   if found then
      select count(*) into n_pompe
      from Pompa
      where Pompa.CodiceStazione = old.CodiceStazione;

      if n_pompe <= 1 then
         raise exception 'La stazione % deve avere almeno una pompa',
            old.CodiceStazione;
      end if;
   end if;

   if (TG_OP = 'DELETE') then
      return old;
   elsif (TG_OP = 'UPDATE') then
      return new;
   end if;
end;
$$;

create trigger pompe_stazione_del
before delete on Pompa
for each row execute function verifica_pompe_stazione();

create trigger pompe_stazione_upd
before update on Pompa
for each row
when (new.CodiceStazione <> old.CodiceStazione)
execute function verifica_pompe_stazione();

--ogni dipendente ha almeno una voce di piano di lavoro
--(DIPENDENTE (1,N) in APPARTIENE A)
create or replace function verifica_piano_dipendente()
returns trigger language plpgsql as
$$
declare
   n_voci integer;
begin
   --se il dipendente non esiste piu' (cancellazione o modifica del
   --codice fiscale propagate in cascata) non c'e' nulla da verificare
   perform * from Dipendente where CodiceFiscale = old.CodiceFiscale;
   if found then
      select count(*) into n_voci
      from PianoDiLavoro
      where PianoDiLavoro.CodiceFiscale = old.CodiceFiscale;

      if n_voci <= 1 then
         raise exception
            'Il dipendente % deve avere almeno una voce di piano',
            old.CodiceFiscale;
      end if;
   end if;

   if (TG_OP = 'DELETE') then
      return old;
   elsif (TG_OP = 'UPDATE') then
      return new;
   end if;
end;
$$;

create trigger piano_dipendente_del
before delete on PianoDiLavoro
for each row execute function verifica_piano_dipendente();

create trigger piano_dipendente_upd
before update on PianoDiLavoro
for each row
when (new.CodiceFiscale <> old.CodiceFiscale)
execute function verifica_piano_dipendente();
