-- inserimento di una stazione di prova insieme ai suoi carburanti e alle
-- sue pompe, in un'unica transazione (OPERAZIONE 1)
start transaction;
insert into Stazione values ('S999', 'A001', 'Udine', 46.06, 13.24);
insert into Offre values
    ('S999', 'Benzina', 10000, 5000),
    ('S999', 'Gasolio', 10000, 5000);
insert into Pompa values
    ('S999', 1, 'Benzina', 'ATTIVA'),
    ('S999', 2, 'Gasolio', 'ATTIVA');
commit;

-- 1: ha successo: la stazione smette di offrire la benzina e la pompa 1,
--    che la erogava, viene cancellata in cascata
delete from Offre
where CodiceStazione = 'S999' and NomeCarburante = 'Benzina';

-- 2: ERRORE: La stazione S999 deve offrire almeno un carburante
delete from Offre where CodiceStazione = 'S999';

-- 3: ERRORE: La stazione S999 deve avere almeno una pompa
delete from Pompa where CodiceStazione = 'S999';

-- 4: ha successo: cambia lo stato dell'unica pompa, non la sua stazione
update Pompa set StatoOperativo = 'MANUTENZIONE'
where CodiceStazione = 'S999';

-- 5: ha successo: la stazione di prova viene cancellata, i suoi carburanti
--    e le sue pompe vengono cancellati in cascata
delete from Stazione where CodiceStazione = 'S999';

-- 6: ERRORE: L'azienda A008 deve possedere almeno una stazione
update Stazione set CodiceAzienda = 'A001' where CodiceAzienda = 'A008';

-- 7: ERRORE: L'azienda A008 deve avere almeno un dipendente
delete from Dipendente where CodiceAzienda = 'A008';

-- 8: ERRORE: Il dipendente TOMELE90D19L483L deve avere almeno una voce di
--    piano
delete from PianoDiLavoro where CodiceFiscale = 'TOMELE90D19L483L';

-- 9: ha successo: inserimento di un nuovo dipendente insieme al suo piano
--    di lavoro, in un'unica transazione (OPERAZIONE 4)
start transaction;
insert into Dipendente values ('BNCLRA90A41L483Z', 'A001', 'Laura', 'Bianchi',
    'Udine', '+393331234567', 1600);
insert into PianoDiLavoro values
    ('BNCLRA90A41L483Z', 'LUN', 'S001', '06:00', '14:00'),
    ('BNCLRA90A41L483Z', 'MAR', 'S001', '06:00', '14:00');
commit;

-- 10: ha successo: il dipendente viene cancellato e il suo piano di lavoro
--     viene cancellato in cascata
delete from Dipendente where CodiceFiscale = 'BNCLRA90A41L483Z';
